import RelationshipValueApp from "./RelationshipValueApp";

export default function Page() {
  return <RelationshipValueApp />;
}
